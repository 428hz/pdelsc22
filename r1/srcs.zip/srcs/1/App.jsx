import React from 'react'; //importa el react
import HolaMundo from './HolaMundo.jsx'; // importa el el codigo 

function App() {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <HolaMundo /> 
    </div>
  );// toda la alineacion
}

export default App;